(* Created with the Wolfram Language : www.wolfram.com *)
{eps^2*mm^(2*eps)*G[0, 0, 0, 0, 0, 0, 2, 0, 2], 
 -(eps^2*mm^(2*eps)*Sqrt[4*mm - t]*Sqrt[-t]*G[0, 0, 0, 0, 0, 0, 1, 2, 2]), 
 -(eps^2*mm^(2*eps)*Sqrt[4*mm - s]*Sqrt[-s]*G[0, 0, 2, 1, 0, 0, 0, 0, 2]), 
 -(eps^2*mm^(2*eps)*Sqrt[4*mm - pp4]*Sqrt[-pp4]*G[0, 1, 2, 0, 0, 0, 0, 0, 
    2]), -(eps^3*mm^(2*eps)*(pp4 - t)*G[0, 0, 0, 1, 0, 0, 1, 1, 2]), 
 eps^3*mm^(2*eps)*t*G[0, 0, 1, 0, 0, 0, 1, 1, 2], 
 eps^3*mm^(2*eps)*s*G[0, 0, 1, 1, 0, 0, 0, 1, 2], 
 -(eps^3*mm^(2*eps)*(pp4 - s)*G[0, 0, 1, 1, 0, 0, 1, 0, 2]), 
 eps^2*mm^(2*eps)*Sqrt[4*mm - pp4]*Sqrt[-pp4]*Sqrt[4*mm - t]*Sqrt[-t]*
  G[0, 1, 0, 0, 0, 0, 1, 2, 2], -(eps^2*mm^(2*eps)*(4*mm - pp4)*pp4*
   G[0, 1, 0, 1, 0, 0, 2, 0, 2]), eps^2*mm^(2*eps)*Sqrt[4*mm - pp4]*
  Sqrt[-pp4]*Sqrt[4*mm - s]*Sqrt[-s]*G[0, 1, 1, 2, 0, 0, 0, 0, 2], 
 -(eps^3*mm^(2*eps)*Sqrt[-s]*Sqrt[-t]*Sqrt[4*mm*pp4 - 4*mm*s - 4*mm*t + s*t]*
   G[0, 0, 1, 1, 0, 0, 1, 1, 2]), eps^3*mm^(2*eps)*Sqrt[4*mm - pp4]*
  Sqrt[-pp4]*(pp4 - t)*G[0, 1, 0, 1, 0, 0, 1, 1, 2], 
 eps^3*mm^(2*eps)*Sqrt[4*mm - pp4]*Sqrt[-pp4]*t*G[0, 1, 1, 0, 0, 0, 1, 1, 2], 
 eps^3*mm^(2*eps)*Sqrt[4*mm - pp4]*Sqrt[-pp4]*s*G[0, 1, 1, 1, 0, 0, 0, 1, 2], 
 eps^3*mm^(2*eps)*Sqrt[4*mm - pp4]*Sqrt[-pp4]*(pp4 - s)*
  G[0, 1, 1, 1, 0, 0, 1, 0, 2], eps^3*mm^(2*eps)*Sqrt[4*mm - pp4]*Sqrt[-pp4]*
  Sqrt[-s]*Sqrt[-t]*Sqrt[4*mm*pp4 - 4*mm*s - 4*mm*t + s*t]*
  G[0, 1, 1, 1, 0, 0, 1, 1, 2]}
