(* Created with the Wolfram Language : www.wolfram.com *)
{eps^2*G[2, 0, 0, 2, 0, 0, 0, 0, 0], eps^2*Sqrt[4*mmb - s]*Sqrt[-s]*
  G[2, 0, 1, 2, 0, 0, 0, 0, 0], eps^3*s*G[1, 1, 1, 2, 0, 0, 0, 0, 0], 
 eps^2*Sqrt[4*mmt - s]*Sqrt[-s]*G[2, 0, 0, 2, 0, 1, 0, 0, 0], 
 -(eps^2*Sqrt[4*mmb - s]*Sqrt[4*mmt - s]*s*G[2, 0, 1, 2, 0, 1, 0, 0, 0]), 
 eps^3*Sqrt[4*mmt - s]*Sqrt[-s]*s*G[1, 1, 1, 2, 0, 1, 0, 0, 0], 
 eps^2*Sqrt[4*mmt - pp4]*Sqrt[-pp4]*G[2, 0, 0, 2, 1, 0, 0, 0, 0], 
 eps^2*Sqrt[4*mmt - pp4]*Sqrt[-pp4]*Sqrt[4*mmb - s]*Sqrt[-s]*
  G[2, 0, 1, 2, 1, 0, 0, 0, 0], eps^3*Sqrt[4*mmt - pp4]*Sqrt[-pp4]*s*
  G[1, 1, 1, 2, 1, 0, 0, 0, 0], eps^3*(pp4 - s)*G[2, 0, 0, 1, 1, 1, 0, 0, 0], 
 eps^3*Sqrt[4*mmb - s]*(pp4 - s)*Sqrt[-s]*G[2, 0, 1, 1, 1, 1, 0, 0, 0], 
 eps^4*(pp4 - s)*s*G[1, 1, 1, 1, 1, 1, 0, 0, 0]}
