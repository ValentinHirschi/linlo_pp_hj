(* Created with the Wolfram Language : www.wolfram.com *)
{eps*mm^eps*G[2, 0, 0, 0], -(eps*mm^eps*Sqrt[4*mm - s]*Sqrt[-s]*
   G[0, 2, 1, 0]), -(eps*mm^eps*Sqrt[4*mm - t]*Sqrt[-t]*G[2, 0, 0, 1]), 
 -(eps*mm^eps*Sqrt[4*mm - pp4]*Sqrt[-pp4]*G[0, 0, 2, 1]), 
 eps^2*mm^eps*t*G[1, 1, 0, 1], eps^2*mm^eps*s*G[1, 1, 1, 0], 
 eps^2*mm^eps*(pp4 - t)*G[1, 0, 1, 1], eps^2*mm^eps*(pp4 - s)*G[0, 1, 1, 1], 
 -(eps^2*mm^eps*Sqrt[-s]*Sqrt[-t]*Sqrt[4*mm*pp4 - 4*mm*s - 4*mm*t + s*t]*
   G[1, 1, 1, 1])}
