cd ..; ./clean_grid_store.sh; cd -; cp HEFT_mint_grids mint_grids; cp HEFT_grid.MC_integer grid.MC_integer; cd ..; rm madevent_mintFO; make madevent_mintFO; cd -; ../madevent_mintFO < input_app.txt;
