touch fm_grid.dat
touch n_samples.dat
cat /dev/null > fm_grid.dat
echo "0" > n_samples.dat
